<?php

//add scripts( fpp means facebook page plugin )

function fpp_add_scripts(){
	wp_enqueue_style('fpp-main-style', plugins_url() . '/facebook-page-plugin/css/style.css');
	wp_enqueue_script('fpp-main-script', plugins_url().'/facebook-page-plugin/js/main.js',array('jquery'));
}
add_action('admin_print_styles', 'fpp_add_scripts');



