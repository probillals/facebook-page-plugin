<?php

/*
Plugin Name: Facebook Page Plugin
Description: Show a Facebook page Plugin (Likebox)
Version: 1.0.0
Author: Billal Hossain
*/


// No one directly access our plugin
//Exit if Accessed Directly
 
if (!defined('ABSPATH')){
	exit;
	}


// Load Script
require_once(plugin_dir_path(__FILE__) . '/includes/facebook-page-plugin-scripts.php');

// Load Class
require_once(plugin_dir_path(__FILE__) . '/includes/facebook-page-plugin-class.php');
//Register Widget

function register_facebook_page_plugin(){
	register_widget('Facebook_Page_Plugin_Widget');
}
add_action('widgets_init', 'register_facebook_page_plugin');


