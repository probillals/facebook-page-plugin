This is a Widget plugin 
++++++++++++++++++++++++++++++++++++++++++
It helps us to keep facebook pages visible to webpages with different conditions
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++